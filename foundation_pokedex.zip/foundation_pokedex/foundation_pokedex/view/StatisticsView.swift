//
//  StatisticsView.swift
//  foundation_pokedex
//
//  Created by Diego Saragoza Da Silva on 18/03/25.
//

import SwiftUI

struct StatisticsView : View {
    var body : some View {
        Text("Estatisticas")
    }
}

#Preview {
    StatisticsView()
}
