//
//  PokedexView.swift
//  foundation_pokedex
//
//  Created by Diego Saragoza Da Silva on 18/03/25.
//

import SwiftUI

struct PokedexView : View {
    var body : some View {
        Text("Pokedex")
    }
}

#Preview {
    PokedexView()
}
