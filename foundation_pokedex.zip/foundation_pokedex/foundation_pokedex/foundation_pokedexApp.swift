//
//  foundation_pokedexApp.swift
//  foundation_pokedex
//
//  Created by Diego Saragoza Da Silva on 18/03/25.
//

import SwiftUI

@main
struct foundation_pokedexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
